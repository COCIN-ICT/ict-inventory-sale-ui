import { Component } from '@angular/core';



@Component({
  selector: 'app-unit',
  templateUrl: './unit.component.html',
  styleUrl: './unit.component.css'
})
export class UnitComponent {}
