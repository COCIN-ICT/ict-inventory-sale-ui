import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-item-list',
  templateUrl: './purchase-item-list.component.html',
  styleUrl: './purchase-item-list.component.css'
})
export class PurchaseItemListComponent {

}
