import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-item-form',
  templateUrl: './purchase-item-form.component.html',
  styleUrl: './purchase-item-form.component.css'
})
export class PurchaseItemFormComponent {

}
