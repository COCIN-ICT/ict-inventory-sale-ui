export const environment = {
  production: false,
  apiUrl: 'http://localhost:9092/api/v1'
  
}; 