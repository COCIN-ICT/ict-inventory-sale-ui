export const environment = {
  production: true,
  apiUrl: 'http://localhost:9091/api/v1'
}; 