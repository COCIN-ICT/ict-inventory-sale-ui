import { Component } from '@angular/core';

@Component({
  selector: 'app-deactivated-users',
  templateUrl: './deactivated-users.component.html',
  styleUrl: './deactivated-users.component.css'
})
export class DeactivatedUsersComponent {

}
