export const environment = {
  production: false,
  apiUrl: 'http://localhost:9091/api/v1'
  
}; 