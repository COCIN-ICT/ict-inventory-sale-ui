import { Pricing } from './pricing.model';

describe('Pricing', () => {
  it('should create an instance', () => {
    expect(new Pricing()).toBeTruthy();
  });
});
