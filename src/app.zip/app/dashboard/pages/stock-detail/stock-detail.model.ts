export class StockDetail {
}
