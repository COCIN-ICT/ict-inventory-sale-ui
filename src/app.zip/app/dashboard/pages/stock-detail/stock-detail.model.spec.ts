import { StockDetail } from './stock-detail.model';

describe('StockDetail', () => {
  it('should create an instance', () => {
    expect(new StockDetail()).toBeTruthy();
  });
});
