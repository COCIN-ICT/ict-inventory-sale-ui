import { Component } from '@angular/core';

@Component({
  selector: 'app-proudction-order-form',
  templateUrl: './proudction-order-form.component.html',
  styleUrl: './proudction-order-form.component.css'
})
export class ProudctionOrderFormComponent {

}
