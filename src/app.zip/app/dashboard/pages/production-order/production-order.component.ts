import { Component } from '@angular/core';

import { RouterOutlet } from "@angular/router";


@Component({
  selector: 'app-production-order',
  templateUrl: './production-order.component.html',
  styleUrl: './production-order.component.css'

})
export class ProductionOrderComponent {

}
