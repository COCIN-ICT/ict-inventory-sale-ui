export class StockTransfer {
}
