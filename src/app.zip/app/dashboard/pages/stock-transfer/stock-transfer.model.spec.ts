import { StockTransfer } from './stock-transfer.model';

describe('StockTransfer', () => {
  it('should create an instance', () => {
    expect(new StockTransfer()).toBeTruthy();
  });
});
