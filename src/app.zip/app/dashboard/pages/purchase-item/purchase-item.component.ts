import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-item',
  templateUrl: './purchase-item.component.html',
  styleUrl: './purchase-item.component.css'
})
export class PurchaseItemComponent {

}
