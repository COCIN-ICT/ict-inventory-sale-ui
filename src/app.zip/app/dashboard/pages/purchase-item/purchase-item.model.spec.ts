import { PurchaseItem } from './purchase-item.model';

describe('PurchaseItem', () => {
  it('should create an instance', () => {
    expect(new PurchaseItem()).toBeTruthy();
  });
});
