export const APPURL = 'http://localhost:9091/api/v1'; // Base URL for the API

// export const APPURL = 'http://localhost:9091/api/v1'; // Base URL for the API