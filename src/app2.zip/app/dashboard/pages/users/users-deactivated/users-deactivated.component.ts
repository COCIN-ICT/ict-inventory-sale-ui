import { Component } from '@angular/core';

@Component({
  selector: 'app-users-deactivated',
  templateUrl: './users-deactivated.component.html',
  styleUrl: './users-deactivated.component.css'
})
export class UsersDeactivatedComponent {

}
