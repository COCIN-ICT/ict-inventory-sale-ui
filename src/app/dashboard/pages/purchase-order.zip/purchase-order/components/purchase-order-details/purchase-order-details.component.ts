import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-order-details',
  templateUrl: './purchase-order-details.component.html',
  styleUrl: './purchase-order-details.component.css'
})
export class PurchaseOrderDetailsComponent {

}
