import { PurchaseOrder } from './purchase-order.model';

describe('PurchaseOrder', () => {
  it('should create an instance', () => {
    expect(new PurchaseOrder()).toBeTruthy();
  });
});
