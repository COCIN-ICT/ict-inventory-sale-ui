import { AuthState } from './auth/auth.state';

export interface AppState {
    auth: AuthState
}