export interface Permission {
  id?: number;
  roleId?: number;
  permissionType: string;
}
