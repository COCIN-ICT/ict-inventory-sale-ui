import { PermissionModel } from './permission.model';

describe('PermissionModel', () => {
  it('should create an instance', () => {
    expect(new PermissionModel()).toBeTruthy();
  });
});
