import { Component, OnInit } from '@angular/core';
import { Role, Unit, User, UserDisplay } from '../../users.model';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../../../../services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'; // New imports

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrl: './user-details.component.css'
})
export class UserDetailsComponent implements OnInit {

  user: UserDisplay | undefined;
  units: Unit[] = [];
  roles: Role[] = [];
  isLoading = true;
  error: string | null = null;
  userForm: FormGroup; // Declare the form group
  isEditMode = false; // To toggle between view and edit mode

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private fb: FormBuilder // Inject FormBuilder
  ) {
    // Initialize the form with empty values and validators
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      middleName: [''],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      address: ['', Validators.required],
      phone: ['', Validators.required], 
      email: ['', [Validators.required, Validators.email]],
      unitId: [null, Validators.required],
      roleId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.userService.getUnits().subscribe(units => this.units = units);
    this.userService.getRoles().subscribe(roles => this.roles = roles);
    
    this.route.paramMap.subscribe(params => {
      const userId = Number(params.get('id'));
      if (userId) {
        this.fetchUserDetails(userId);
      } else {
        this.error = 'User ID not found in URL.';
        this.isLoading = false;
        this.router.navigate(['/home/user-management/users']);
      }
    });
  }

fetchUserDetails(id: number): void {
    this.isLoading = true;
    this.error = null;
    this.userService.getUserById(id).subscribe({
      next: (user) => {
        // Find the unit name based on the user's unitId
        const unit = this.units.find(u => u.id === user.unitId);
        // Find the role name based on the user's roleId
        const role = this.roles.find(r => r.id === user.roleId);

        // Assign the found names to the user object for display
        this.user = {
          ...user,
          unitName: unit ? unit.name : 'N/A',
          roleName: role ? role.name : 'N/A'
        };
        this.userForm.patchValue(this.user);
        this.isLoading = false;
      },
      error: (err) => {
        this.error = 'Failed to load user details. Please try again.';
        this.isLoading = false;
        console.error('Error fetching user:', err);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/home/user-management/users']);
  }

  toggleEditMode(): void {
    this.isEditMode = !this.isEditMode;
  }

  saveChanges(): void {
    if (this.userForm.valid && this.user) {
      const updatedUser: User = {
        ...this.user, // Spread existing properties to retain any not in the form
        ...this.userForm.value,
      };

      this.userService.updateUser(this.user.id!, updatedUser).subscribe({
        next: () => {
          this.toggleEditMode(); // Exit edit mode on success
          // Re-fetch user details to display the latest data
          this.fetchUserDetails(this.user!.id!);
        },
        error: (err) => {
          this.error = 'Failed to update user. Please try again.';
          console.error('Error updating user:', err);
        }
      });
    }
  }

  cancelEdit(): void {
    this.userForm.patchValue(this.user!); // Reset form to original values
    this.toggleEditMode(); // Exit edit mode
  }
}