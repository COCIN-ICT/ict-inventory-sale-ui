export interface User {
  id?: number;
  firstName: string;
  lastName: string;
  middleName: string;
  username: string;
  password: string;
  address: string;
  phone: string;
  email: string;
  roleId: number;
  role: { id: number; name: string; };
  unitId: number;
  unit: { id: number; name: string; };  
}

export interface Unit {
  id: number;
  name: string;
}

export interface Role {
  id: number;
  name: string;
}

// Add this new interface
export interface UserDisplay extends User {
  unitName?: string;
  roleName?: string;
}